#include "graphicCard.h"

graphicCard::graphicCard()
{

    brand = "";
    memorySize = 1;
    price = 0;
}

double graphicCard::getPrice()
{
    return price;
}


